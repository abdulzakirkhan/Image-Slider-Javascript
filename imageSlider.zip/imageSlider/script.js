const wrapper = document.querySelector(".wrapper");
const carousel = document.querySelector(".carousel");
const firstCardWidth = carousel.querySelector(".card").offsetWidth;
const arrowBtns = document.querySelectorAll(".wrapper i");
const carouselChildrens = [...carousel.children]; // through spread operator store the// study about this
// console.log(firstCardWidth);    Study about this topic

let isDragging = false, isAutoPlay = true, startX, startScrollLeft, timeoutId;
let cardPerView = Math.round(carousel.offsetWidth / firstCardWidth);// strat scroll left
// console.log(typeof -cardPerView); // position number index number
carouselChildrens.slice(-cardPerView).reverse().forEach(card => {
    // console.log(-cardPerView)
    carousel.insertAdjacentHTML("afterbegin", card.outerHTML);  // study about this
    // console.log(card.outerHTML)
});

carouselChildrens.slice(0, cardPerView).forEach(card => {
    carousel.insertAdjacentHTML("beforeend", card.outerHTML);
});

carousel.classList.add("no-transition");
carousel.scrollLeft = carousel.offsetWidth;
carousel.classList.remove("no-transition");
arrowBtns.forEach(btn => {
    btn.addEventListener("click", () => {
        const left=carousel.scrollLeft = btn.id == "left";
        const right=carousel.scrollLeft = btn.id == "right";
        carousel.scrollLeft += btn.id == "left" ? -firstCardWidth : firstCardWidth;
        console.log("Left:",left);
        console.log("Right:",right);
    });
});
//  yahy tak   
const dragStart = (e) => {
    isDragging = true;
    carousel.classList.add("dragging");
    startX = e.pageX;
    startScrollLeft = carousel.scrollLeft;
    console.log(startScrollLeft);

}

const dragging = (e) => {
    if(!isDragging) return; 
    carousel.scrollLeft = startScrollLeft - (e.pageX - startX);
}

const dragStop = () => {
    isDragging = false;
    carousel.classList.remove("dragging");
}


const infiniteScroll = () => {
    if(carousel.scrollLeft === 0) {
        carousel.classList.add("no-transition");
        carousel.scrollLeft = carousel.scrollWidth - (2 * carousel.offsetWidth);
        carousel.classList.remove("no-transition");
    }
    else if(Math.ceil(carousel.scrollLeft) === carousel.scrollWidth - carousel.offsetWidth) {
        carousel.classList.add("no-transition");
        carousel.scrollLeft = carousel.offsetWidth;
        carousel.classList.remove("no-transition");
    }
    clearTimeout(timeoutId);
    if(!wrapper.matches(":hover")) autoPlay();
}

const autoPlay = () => {
    if(window.innerWidth < 800 || !isAutoPlay) return;
    timeoutId = setTimeout(() => carousel.scrollLeft += firstCardWidth, 2500);
}
autoPlay();




carousel.addEventListener("mousedown", dragStart);
carousel.addEventListener("mousemove", dragging);
document.addEventListener("mouseup", dragStop);
carousel.addEventListener("scroll", infiniteScroll);
wrapper.addEventListener("mouseenter", () => clearTimeout(timeoutId));
wrapper.addEventListener("mouseleave", autoPlay);















const mun=document.getElementById("right");

mun.addEventListener('mouseenter',() => {
    console.log("Mouse Entered")
})

mun.addEventListener("mousedown",() =>{
    console.log("mouse down");
})
mun.addEventListener("mousemove",() => {
    console.log("Mouse Move");
})
mun.addEventListener("mouseout",() => {
    console.log("mouse Out");
})
mun.addEventListener("mouseleave",()=>{
    console.log("Mouse leave");
})
mun.addEventListener("mouseover",() =>  {
    console.log("Mouse Over");
})







// const body=document.body;
// const xpage=document.getElementById("pageX");
// const ypage=document.getElementById("pageY");
// function updateDisplay(e)
// {
//     xpage.innerText=e.pageX;
//     ypage.innerText=e.pageY;
//     console.log(e.pageX)
//     console.log(e.pagey)
// }
// body.addEventListener('mouseenter',updateDisplay)
// body.addEventListener('mouseup',updateDisplay)
// console.log(xpage);
// console.log(ypage);





// let a =[10,20,30,40]
// let b =[...a,50];

// console.log("A",a)
// console.log("B",b)
// a.push(60);
// console.log("A",a);
// console.log("B",b);